#ifndef _TASK_FLASH_H
#define _TASK_FLASH_H

#ifdef __cplusplus
 extern "C" {
#endif 

#define		VCC_MB_DEF			7.5	
#define		VCC_SB_DEF			7.5	
#define		TEMPRETURE_DEF		32.5	
#define		HUMIDITY_DEF		90.1	
#define		CO_DEF				70.1	
#define		H2S_DEF				70.1	
#define		NH3_DEF				70.1	
#define		O2_DEF				70.1	
#define		WATER_DEF			2.5	

#define		DEV_ID				102
struct alarm_value
{
	char msg[200];
	char write_flag;
	float vcc_mb;
	float vcc_sb;
	float tempretrue;
	float humidity;
	float co;
	float h2s;
	float nh3;
	float o2;
	float water;
	int user;
	int password;
	int id;
};


extern struct alarm_value  alarmdata;
/****************************************************************************
 * Private Data
 ****************************************************************************/
int master_flash(int argc, char *argv[]);

/****************************************************************************
 * Private function
 ****************************************************************************/




#ifdef __cplusplus
}
#endif

#endif 
