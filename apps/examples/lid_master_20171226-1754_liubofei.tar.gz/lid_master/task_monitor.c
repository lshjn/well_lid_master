#include <sys/ioctl.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sched.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>

#include <nuttx/analog/adc.h>
#include <nuttx/analog/ioctl.h>
#include <nuttx/leds/userled.h>
#include <nuttx/board.h>
#include <sys/boardctl.h>

#include <nuttx/board.h>
#include <sys/boardctl.h>
#include <errno.h>
#include <nuttx/ioexpander/gpio.h>

#include "task_adc.h"
#include "task_flash.h"
#include "task_485.h"
#include "task_gprs.h"
#include "task_bluetooth.h"
#include "task_monitor.h"
#include "task_motor.h"

/*****************************************************************************************************************************
 * Private Data
 ****************************************************************************************************************************/
pthread_mutex_t g_TimIntMutex		= PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t g_MonitorMutex		= PTHREAD_MUTEX_INITIALIZER;

static		bool  		g_monitor_started;

char		TimeInt_SampleFlag = 0;


struct  	TimeStruct  DisLocalTime;
struct		tm 			*tmp;
struct 		rtc_time	rtctime;
time_t		timelocal;

/****************************************************************************
 * getSystime
 * liushuhe
 * 2017.10.11
 ****************************************************************************/
void  getSystime(void)
{
	time(&timelocal);	
	tmp = localtime(&timelocal);  //��ȡ����ʱ��


	DisLocalTime.Year		=	1900+tmp->tm_year;
	DisLocalTime.Month		=	tmp->tm_mon + 1;
	DisLocalTime.Day		=	tmp->tm_mday;
	DisLocalTime.Hour		=	tmp->tm_hour;
	DisLocalTime.Minute	=	tmp->tm_min;
	DisLocalTime.Second	=	tmp->tm_sec;
}
/****************************************************************************
 * setSystime
 * liushuhe
 * 2017.10.11
 ****************************************************************************/
int setSystime(struct rtc_time *rtc)
{
	//struct rtc_time rtc;  
	struct tm _tm;  
	struct timeval tv;  
	time_t timep;  

	_tm.tm_sec 	= rtc->tm_sec;  
	_tm.tm_min 	= rtc->tm_min;  
	_tm.tm_hour = rtc->tm_hour;  
	_tm.tm_mday = rtc->tm_mday;  
	_tm.tm_mon 	= rtc->tm_mon - 1;  
	_tm.tm_year = rtc->tm_year - 1900;  

	timep = mktime(&_tm);  
	tv.tv_sec = timep;  
	tv.tv_usec = 0;  
	if(settimeofday (&tv, (struct timezone *) 0) < 0)  
	{  
		printf("Set system datatime error!/n");  
		return -1;  
	}  
	return 0;  

}
/****************************************************************************
 * setRtcTime
 * liushuhe
 * 2017.10.18
 ****************************************************************************/
int setRtcTime(int fd,struct rtc_time *rtc)
{
	int ret;
	ret = ioctl(fd, RTC_SET_TIME,(unsigned long)((uintptr_t)rtc));
	if (ret < 0)
	{
		int errcode = errno;
		printf("getRtcTime: ERROR: ioctl(ULEDIOC_SUPPORTED) failed: %d\n",errcode);
		return -1;
	}
	return 1;

}
/****************************************************************************
 * getRtcTime
 * liushuhe
 * 2017.10.18
 ****************************************************************************/
int getRtcTime(int fd,struct rtc_time *rtc)
{
	int ret;
	ret = ioctl(fd, RTC_RD_TIME,(unsigned long)((uintptr_t)rtc));
	if (ret < 0)
	{
		int errcode = errno;
		printf("getRtcTime: ERROR: ioctl(ULEDIOC_SUPPORTED) failed: %d\n",errcode);
		return -1;
	}

	//year + 1900
	rtc->tm_year = rtc->tm_year + 1900;
	//tm_mon + 1
	rtc->tm_mon = rtc->tm_mon + 1;
	
	return 1;
}

/******************************************************************************************************************************
�������ƣ�int	CheckTimeInt(void)
��    �ܣ��ж��Ƿ񵽴ﶨʱ�ɼ�ʱ��
�����������
���������1:ʹ��	0:��ֹ
��дʱ�䣺2017.09.29
�� д �ˣ�liushuhe
*******************************************************************************************************************************/
int	CheckTimeInt(void)
{
	//��ȡ����ʱ��
	getSystime();
	
	printf("time:%d-%d-%d-%d-%d-%d\n",DisLocalTime.Year,DisLocalTime.Month,DisLocalTime.Day,
						  DisLocalTime.Hour,DisLocalTime.Minute,DisLocalTime.Second);
	//changed by liubofei 2017-12-26
	if(((7 == DisLocalTime.Hour)&&(0 == DisLocalTime.Minute)&&(0 == DisLocalTime.Second))||
	   ((20 == DisLocalTime.Hour)&&(0 == DisLocalTime.Minute)&&(0 == DisLocalTime.Second)))
	{
		return	1;
	}
	else
	{
		return 0;
	}
}


/****************************************************************************
 * warn_upload_process
 * liushuhe
 * 2017.09.28
 ****************************************************************************/
void warn_upload_process(int fd,int *locker,struct gprs_data	*gprsdata,struct adc_msg *adc_dada,struct hall_sensor *sensor)
{
	int ret = FAIL;
	int cnt = 0;
//changed by liubofei 2017-12-26 (check lockstate --> report data )
	int fd_sensora;
	int fd_sensorb;
	int cnt_lock = 0;
	*locker = ASK_OPENLOCK;

	fd_sensora = open(CONFIG_EXAMPLES_SENSORA_DEVPATH, O_RDONLY);
	if (fd_sensora < 0)
	{
		printf("fd_sensora: open %s failed: %d\n", CONFIG_EXAMPLES_SENSORA_DEVPATH, errno);
	}

	fd_sensorb = open(CONFIG_EXAMPLES_SENSORB_DEVPATH, O_RDONLY);
	if (fd_sensorb < 0)
	{
		printf("fd_sensorb: open %s failed: %d\n", CONFIG_EXAMPLES_SENSORB_DEVPATH, errno);
	}

	while(strcmp(sensor->lockstr,"on"))
	{
		check_lockstate(fd_sensora,fd_sensorb,&Hall_Sensor);
		usleep(500*1000);//0.5s
		if(cnt_lock++ > 60)
		{
				cnt_lock = 0;
			//	close(fd_sensora);
			//	close(fd_sensorb);
			break;
		}
	}
	close(fd_sensora);
	close(fd_sensorb);
//end	
	while(ret == FAIL)
	{
		ret = gprs_rst(fd,gprsdata);
		if(cnt++ > 3)
		{
			cnt = 0;
			Gprsfail_buzz_alarm();			
			break;
		}
	}
		
	if(ret == SUCCESS)
	{
		ret = gprs_warn_upload(fd,gprsdata,adc_dada,sensor);
		if(ret == SUCCESS)
		{
			printf("warn upload ok\n");
			gprsdata->process_state = SUCCESS;
		}
		else if(ret == FAIL)
		{
			printf("warn upload fail\n");
			gprsdata->process_state = FAIL;
		}
	}
	else
	{
		//ask open lock
		printf("gprs connect fail\n");
	}
	//ask open lock
//	*locker = ASK_OPENLOCK;//closed by liubofei
}

/****************************************************************************
 * timeint_upload_process
 * liushuhe
 * 2017.09.28
 ****************************************************************************/
void timeint_upload_process(int fd,int *locker,struct gprs_data	*gprsdata,struct adc_msg *adc_dada,struct hall_sensor *sensor)
{
	int ret = FAIL;
	int cnt = 0;
//changed by liubofei 2017-12-26 (check lockstate --> report data )
	int fd_sensora;
	int fd_sensorb;
	int cnt_lock = 0;
	*locker = ASK_CLOSELOCK;

	fd_sensora = open(CONFIG_EXAMPLES_SENSORA_DEVPATH, O_RDONLY);
	if (fd_sensora < 0)
	{
		printf("fd_sensora: open %s failed: %d\n", CONFIG_EXAMPLES_SENSORA_DEVPATH, errno);
	}

	fd_sensorb = open(CONFIG_EXAMPLES_SENSORB_DEVPATH, O_RDONLY);
	if (fd_sensorb < 0)
	{
		printf("fd_sensorb: open %s failed: %d\n", CONFIG_EXAMPLES_SENSORB_DEVPATH, errno);
	}

	while(strcmp(sensor->lockstr,"off"))
	{
		check_lockstate(fd_sensora,fd_sensorb,&Hall_Sensor);
		usleep(500*1000);//0.5s
		if(cnt_lock++ > 60)
		{
				cnt_lock = 0;
				//close(fd_sensora);
				//close(fd_sensorb);
				break;
		}
	}
	close(fd_sensora);
	close(fd_sensorb);
//end
	
	while(ret == FAIL)
	{
		ret = gprs_rst(fd,gprsdata);
		if(cnt++ > 3)
		{
			cnt = 0;
			Gprsfail_buzz_alarm();			
			break;
		}
	}

	if(ret == SUCCESS)
	{
		ret = gprs_timeint_upload(fd,gprsdata,adc_dada,sensor);
		if(ret == SUCCESS)
		{
			printf("timeint upload ok\n");
			if(gprsdata->download_data.locker == ENABLE)
			{
				//��ʱ�ϱ�ֻ�ܹ��������ܿ���
				//ask open lock
				//*locker = ASK_OPENLOCK;
			}
			else if(gprsdata->download_data.locker == DISABLE)
			{
				//ask close lock
				*locker = ASK_CLOSELOCK;
			}
			gprsdata->process_state = SUCCESS;
		}
		else
		{
			//ask close lock
			*locker = ASK_CLOSELOCK;
			printf("timeint upload fail\n");
			gprsdata->process_state = FAIL;
		}
	}
	else
	{
		//ask close lock
		*locker = ASK_CLOSELOCK;
		printf("gprs connect fail\n");
	}
}
/****************************************************************************
 * w315mhz_ask_openlock_process
 * liushuhe
 * 2017.09.28
 ****************************************************************************/
void w315mhz_ask_openlock_process(int fd,int *locker,struct gprs_data	*gprsdata,struct adc_msg *adc_dada,struct hall_sensor *sensor)
{
	int ret = FAIL;
	int cnt = 0;
	while(ret == FAIL)
	{
		ret = gprs_rst(fd,gprsdata);
		if(cnt++ > 3)
		{
			cnt = 0;
			Gprsfail_buzz_alarm();			
			break;
		}
	}
	if(ret == SUCCESS)
	{
	//new add by liubofei 2017-12-26
		memset(gprsdata->msgbuf, 0, sizeof(gprsdata->msgbuf));
		/*sprintf(gprsdata->msgbuf,"##time=%4d%d%d%d%d%d%d%d%d%d%d;msgtype=openlock#request;locker=%s;mb=%.2f;tempretrue=%s;humidity=%s;co=%s;h2s=%s;nh3=%s;o2=%s;water=%.2f;sb=%.2f;id=%3d@@\n",
								DisLocalTime.Year,DisLocalTime.Month/10,DisLocalTime.Month%10,DisLocalTime.Day/10,DisLocalTime.Day%10,
								DisLocalTime.Hour/10,DisLocalTime.Hour%10,DisLocalTime.Minute/10,DisLocalTime.Minute%10,DisLocalTime.Second/10,DisLocalTime.Second%10,
							  sensor->lockstr,adc_dada->VCC,"NULL","NULL",
							  "NULL","NULL","NULL","NULL",adc_dada->Water_high,adc_dada->VCC,
							  DEV_ID);
		*///changed by liubofei 2017-12-26
		sprintf(gprsdata->msgbuf,"##time=%4d%d%d%d%d%d%d%d%d%d%d;msgtype=openlock#request;locker=%s;mb=%.1f;tempretrue=%s;humidity=%s;co=%s;h2s=%s;nh3=%s;o2=%s;water=%.1f;sb=%.2f;id=%3d@@\n",
								DisLocalTime.Year,DisLocalTime.Month/10,DisLocalTime.Month%10,DisLocalTime.Day/10,DisLocalTime.Day%10,
								DisLocalTime.Hour/10,DisLocalTime.Hour%10,DisLocalTime.Minute/10,DisLocalTime.Minute%10,DisLocalTime.Second/10,DisLocalTime.Second%10,
							  sensor->lockstr,adc_dada->VCC_middle,"NULL","NULL",
							  "NULL","NULL","NULL","NULL",adc_dada->Water_high,adc_dada->VCC_middle,
							  DEV_ID);
	//end	
		ret = gprs_openlock(fd,gprsdata,adc_dada,sensor);
		if(ret == SUCCESS)
		{
			//close by liubofei 2017-12-26 //temporarily remove
			#if 0
			if(gprsdata->download_data.locker == ENABLE)
			{
				//ask open lock
				*locker = ASK_OPENLOCK;
			}
			/*	//close by liubofei 2017-12-26 //temporarily remove
			else if(gprsdata->download_data.locker == DISABLE)
			{
				//ask close lock
				*locker = ASK_CLOSELOCK;
			}
			*/
			#endif
			gprsdata->process_state = SUCCESS;
		}
		else
		{
			//��������ʧ�ܣ�������رգ��߼����ܲ���,��ʱȥ��
			//ask close lock
			//*locker = ASK_CLOSELOCK;
			gprsdata->process_state = FAIL;
		}
		
		//new add by liubofei 2017-12-26
		if(gprsdata->process_state)
		{
			int fd_sensora;
			int fd_sensorb;
			int cnt_lock = 0;

			if(gprsdata->download_data.locker == ENABLE)
			{
				//ask open lock
				*locker = ASK_OPENLOCK;
			}

			fd_sensora = open(CONFIG_EXAMPLES_SENSORA_DEVPATH, O_RDONLY);
			if (fd_sensora < 0)
			{
				printf("fd_sensora: open %s failed: %d\n", CONFIG_EXAMPLES_SENSORA_DEVPATH, errno);
			}

			fd_sensorb = open(CONFIG_EXAMPLES_SENSORB_DEVPATH, O_RDONLY);
			if (fd_sensorb < 0)
			{
				printf("fd_sensorb: open %s failed: %d\n", CONFIG_EXAMPLES_SENSORB_DEVPATH, errno);
			}

			while(strcmp(sensor->lockstr,"on"))
			{
				check_lockstate(fd_sensora,fd_sensorb,&Hall_Sensor);
				usleep(500*1000);//0.5s
				if(cnt_lock++ > 60)
				{
					cnt_lock = 0;
					//close(fd_sensora);
					//close(fd_sensorb);
				}
			}
			close(fd_sensora);
			close(fd_sensorb);
/*
			while(ret == FAIL)
			{
				ret = gprs_rst(fd,gprsdata);
				if(cnt++ > 3)
				{
					cnt = 0;
					Gprsfail_buzz_alarm();			
					break;
				}
			}
			if(ret == SUCCESS)
			{
			*/
				memset(gprsdata->msgbuf, 0, sizeof(gprsdata->msgbuf));
				/*sprintf(gprsdata->msgbuf,"##time=%4d%d%d%d%d%d%d%d%d%d%d;msgtype=openlock#requestok;locker=%s;mb=%.2f;tempretrue=%s;humidity=%s;co=%s;h2s=%s;nh3=%s;o2=%s;water=%.2f;sb=%.2f;id=%3d@@\n",
								DisLocalTime.Year,DisLocalTime.Month/10,DisLocalTime.Month%10,DisLocalTime.Day/10,DisLocalTime.Day%10,
								DisLocalTime.Hour/10,DisLocalTime.Hour%10,DisLocalTime.Minute/10,DisLocalTime.Minute%10,DisLocalTime.Second/10,DisLocalTime.Second%10,
							  sensor->lockstr,adc_dada->VCC,"NULL","NULL",
							  "NULL","NULL","NULL","NULL",adc_dada->Water_high,adc_dada->VCC,
							  DEV_ID);
				*///changed by liubofei 2017-12-26
				sprintf(gprsdata->msgbuf,"##time=%4d%d%d%d%d%d%d%d%d%d%d;msgtype=openlock#requestok;locker=%s;mb=%.1f;tempretrue=%s;humidity=%s;co=%s;h2s=%s;nh3=%s;o2=%s;water=%.1f;sb=%.1f;id=%3d@@\n",
								DisLocalTime.Year,DisLocalTime.Month/10,DisLocalTime.Month%10,DisLocalTime.Day/10,DisLocalTime.Day%10,
								DisLocalTime.Hour/10,DisLocalTime.Hour%10,DisLocalTime.Minute/10,DisLocalTime.Minute%10,DisLocalTime.Second/10,DisLocalTime.Second%10,
							  sensor->lockstr,adc_dada->VCC_middle,"NULL","NULL",
							  "NULL","NULL","NULL","NULL",adc_dada->Water_high,adc_dada->VCC_middle,
							  DEV_ID);
				ret = gprs_openlock(fd,gprsdata,adc_dada,sensor);
			//}

		}
		//end
	}
	else
	{
		//��������ʧ�ܣ�������رգ��߼����ܲ���,��ʱȥ��
		//ask close lock
		//*locker = ASK_CLOSELOCK;
		printf("gprs connect fail\n");
	}
}
/****************************************************************************
 * w315mhz_ask_closelock_process
 * liushuhe
 * 2017.11.27
 ****************************************************************************/
void w315mhz_ask_closelock_process(int fd,int *locker,struct gprs_data	*gprsdata,struct adc_msg *adc_dada,struct hall_sensor *sensor)
{
	int ret = FAIL;
	int cnt = 0;

	int fd_sensora;
	int fd_sensorb;
	//ask close lock
	*locker = ASK_CLOSELOCK;
	
//changed by liubofei 2017-12-26 (check lockstate --> report data )

	int cnt_lock = 0;

	fd_sensora = open(CONFIG_EXAMPLES_SENSORA_DEVPATH, O_RDONLY);
	if (fd_sensora < 0)
	{
		printf("fd_sensora: open %s failed: %d\n", CONFIG_EXAMPLES_SENSORA_DEVPATH, errno);
	}

	fd_sensorb = open(CONFIG_EXAMPLES_SENSORB_DEVPATH, O_RDONLY);
	if (fd_sensorb < 0)
	{
		printf("fd_sensorb: open %s failed: %d\n", CONFIG_EXAMPLES_SENSORB_DEVPATH, errno);
	}

	while(strcmp(sensor->lockstr,"off"))
	{
		check_lockstate(fd_sensora,fd_sensorb,&Hall_Sensor);
		usleep(500*1000);//0.5s
		if(cnt_lock++ > 60)
		{
				cnt_lock = 0;
				//close(fd_sensora);
				//close(fd_sensorb);
				break;
		}
	}
	close(fd_sensora);
	close(fd_sensorb);
//end
	while(ret == FAIL)
	{
		ret = gprs_rst(fd,gprsdata);
		if(cnt++ > 3)
		{
			cnt = 0;
			Gprsfail_buzz_alarm();			
			break;
		}
	}
	if(ret == SUCCESS)
	{
		sprintf(sensor->lockstr,"off");
		ret = gprs_closelock(fd,gprsdata,adc_dada,sensor);
		if(ret == SUCCESS)
		{
			gprsdata->process_state = SUCCESS;
		}
		else
		{
			gprsdata->process_state = FAIL;
		}
	}
	else
	{
		printf("gprs connect fail\n");
	}
}

/****************************************************************************
 * w315mhz_ask_openlock_process
 * liushuhe
 * 2017.09.28
 ****************************************************************************/
void bluetooth_openlock_process(int fd,int  *locker,struct gprs_data	*gprsdata,struct adc_msg *adc_dada,struct hall_sensor *sensor)
{
	int ret = FAIL;
	int cnt = 0;
	while(ret == FAIL)
	{
		ret = gprs_rst(fd,gprsdata);
		if(cnt++ > 3)
		{
			cnt = 0;
			Gprsfail_buzz_alarm();			
			break;
		}
	}
	if(ret == SUCCESS)
	{
		ret = gprs_openlock(fd,gprsdata,adc_dada,sensor);
		if(ret == SUCCESS)
		{
			if(gprsdata->download_data.locker == ENABLE)
			{
				//ask open lock
				*locker = ASK_OPENLOCK;
			}
			else if(gprsdata->download_data.locker == DISABLE)
			{
				//ask close lock
				*locker = ASK_CLOSELOCK;
			}
			gprsdata->process_state = SUCCESS;
		}
		else
		{
			//ask close lock
			*locker = ASK_CLOSELOCK;
			gprsdata->process_state = FAIL;
		}
	}
	else
	{
		//ask close lock
		*locker = ASK_CLOSELOCK;
		printf("gprs connect fail\n");
	}
}
/****************************************************************************
 * master_monitor
 * liushuhe
 * 2017.09.28
 ****************************************************************************/
int master_monitor(int argc, char *argv[])
{
	int fd_gprs_copy;
	int fd_rtc;
	g_monitor_started = false;
	
	fd_gprs_copy = open(CONFIG_EXAMPLES_GPRS_DEVPATH, O_RDWR | O_NOCTTY | O_NONBLOCK | O_NDELAY);
	if (fd_gprs_copy < 0)
	{
		int errcode = errno;
		printf("gprs: ERROR: Failed to open %s: %d\n",CONFIG_EXAMPLES_GPRS_DEVPATH, errcode);
	}
	
	fd_rtc = open(CONFIG_EXAMPLES_RTC_DEVPATH, O_RDWR | O_NOCTTY | O_NONBLOCK | O_NDELAY);
	if (fd_rtc < 0)
	{
		int errcode = errno;
		printf("rtc0: ERROR: Failed to open %s: %d\n",CONFIG_EXAMPLES_RTC_DEVPATH, errcode);
	}
	
	getRtcTime(fd_rtc,&rtctime);
	printf("read rtc:%d%d%d%d%d%d\n",rtctime.tm_year,rtctime.tm_mon,rtctime.tm_mday,
						  rtctime.tm_hour,rtctime.tm_min,rtctime.tm_sec);
	setSystime(&rtctime);
    sleep(5);
	//new add by liubofei 2017-12-26
	first_getvcc(&g_AdcConVar,&g_AdcMutex,DATA_NUM);
	sleep(1);
	//end
	while(1)
	{
		usleep(1000*1000L);                                     //sleep 100ms
		/*************************************************************************/
		//����һ��adc�ɼ�
		//changed by liubofei 2017-12-26
		EnAdcSampl(&g_AdcConVar,&g_AdcMutex);
		
		//getVccValue(&g_AdcConVar,&g_AdcMutex);
		
		if(1==SensorDate.sampleisok)
		{
			SensorDate.sampleisok	= 0;
			/*************************************************************************/
			printf("%s: value: %d \n", "sample_tempdata[0]", SensorDate.sample_tempdata[0].am_data);
			printf("%s: value: %d \n", "sample_tempdata[1]", SensorDate.sample_tempdata[1].am_data);
			printf("%s: value: %d \n", "sample_tempdata[2]", SensorDate.sample_tempdata[2].am_data);
			//VCC
			printf("%s: value: %.2f v\n", "SensorDate.adcmsg.VCC", SensorDate.adcmsg->VCC);
			printf("%s: value: %.2f m\n", "SensorDate.adcmsg.Water_high", SensorDate.adcmsg->Water_high);
			printf("%s: value: %.2f v\n", "SensorDate.adcmsg.Light", SensorDate.adcmsg->Light);

			//new add by liubofei 2017-12-26
			SensorDate.adcmsg->VCCTemp[DATA_NUM-1] = SensorDate.adcmsg->VCC;
			SensorDate.adcmsg->VCC_middle=filter(DATA_NUM);
			//end
			
			/*************************************************************************/
			//�����ϱ�
			//changed by liubofei 2017-12-26
			//if((SensorDate.adcmsg->VCC <= alarmdata.vcc_mb)||(SensorDate.adcmsg->Water_high >= alarmdata.water ))
			
			printf("SensorDate.adcmsg->VCC_middle =%.1f,SensorDate.adcmsg->Water_high=%.1f\n",SensorDate.adcmsg->VCC_middle,SensorDate.adcmsg->Water_high);
			printf("alarmdata.vcc_mb=%.1f,alarmdata.water=%.1f\n",alarmdata.vcc_mb,alarmdata.water);
			if((SensorDate.adcmsg->VCC_middle <= alarmdata.vcc_mb)||(SensorDate.adcmsg->Water_high >= alarmdata.water ))
			{
				if(!pthread_mutex_trylock(&g_MonitorMutex))
				{
					printf("WarningUpload get g_MonitorMutex Lock OK!\n");
					Msg485Data.type 	=	WARN_UPLOAD;
					pthread_mutex_unlock(&g_MonitorMutex);
				}
				else
				{
					printf("WarningUpload get g_MonitorMutex Lock fail!\n");
				}
			}
		}
		/*************************************************************************/
		//485
		switch(Msg485Data.type)
		{
			//warn upload
			case WARN_UPLOAD:
					if(GprsData.process_state != SUCCESS)
					{
						printf("warn_upload_process  starting................\n");
						warn_upload_process(fd_gprs_copy,&Locker,&GprsData,&adcdata,&Hall_Sensor);
					}
					
					Msg485Data.type = WAIT;
					boardctl(BOARDIOC_GPRS_PWROFF, 0);
				break;
			//timeint upload	
			case TIMEINT_UPLOAD:
					if(GprsData.process_state != SUCCESS)
					{
						printf("timeint_upload_process  starting................\n");
						timeint_upload_process(fd_gprs_copy,&Locker,&GprsData,&adcdata,&Hall_Sensor);
					}
					Msg485Data.type = WAIT;
					boardctl(BOARDIOC_GPRS_PWROFF, 0);
				break;
			//open lock
			case OPEN_LOCK:
					if(GprsData.process_state != SUCCESS)
					{
						printf("w315mhz_ask_openlock_process  starting................\n");
						w315mhz_ask_openlock_process(fd_gprs_copy,&Locker,&GprsData,&adcdata,&Hall_Sensor);
					}
					Msg485Data.type = WAIT;
					boardctl(BOARDIOC_GPRS_PWROFF, 0);
				break;
			//close lock
			case CLOSE_LOCK:
					if(GprsData.process_state != SUCCESS)
					{
						printf("w315mhz_ask_closelock_process  starting................\n");
						w315mhz_ask_closelock_process(fd_gprs_copy,&Locker,&GprsData,&adcdata,&Hall_Sensor);
					}
					Msg485Data.type = WAIT;
					boardctl(BOARDIOC_GPRS_PWROFF, 0);
				break;
		}
		//bluetooth
		switch(bluetooth_msg.type)
		{
			//open lock
			case BT_OPEN_LOCK:
					if(GprsData.process_state != SUCCESS)
					{
						bluetooth_msg.type = WAIT;
						printf("bluetooth_openlock_process  starting................\n");
						bluetooth_openlock_process(fd_gprs_copy,&Locker,&GprsData,&adcdata,&Hall_Sensor);
						Msg485Data.type = POWER_OFF;
					}
					else
					{
						Msg485Data.type = WAIT;
					}
					boardctl(BOARDIOC_GPRS_PWROFF, 0);
				break;
		}
		/*************************************************************************/
		//��ʱ�ɼ� 8:00 | 18:00
		if(1 == TimeInt_SampleFlag)
		{
  			pthread_mutex_lock(&g_TimIntMutex);
			sleep(1);
			TimeInt_SampleFlag = 0;	
			pthread_mutex_unlock(&g_TimIntMutex);
			if(0 == pthread_mutex_trylock(&g_MonitorMutex))
			{
				printf("TimeIntUpload get g_MonitorMutex Lock OK!\n");
				Msg485Data.type 	=	TIMEINT_UPLOAD;
				pthread_mutex_unlock(&g_MonitorMutex);
			}
			else
			{
				printf("TimeIntUpload get g_MonitorMutex Lock fail!\n");
			}
		}
		/*************************************************************************/

	}
  printf("master_monitor: Terminating\n");

 return EXIT_FAILURE;

}


