#include <sys/ioctl.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sched.h>
#include <errno.h>
#include <nuttx/leds/userled.h>
#include <nuttx/board.h>
#include <sys/boardctl.h>
#include <nuttx/analog/adc.h>
#include <nuttx/analog/ioctl.h>
#include <nuttx/board.h>
#include <sys/boardctl.h>
#include <errno.h>
#include <nuttx/ioexpander/gpio.h>

#include <nuttx/mtd/mtd.h>
#include <nuttx/drivers/drivers.h>
#include <nuttx/fs/ioctl.h>


#include "task_monitor.h"
#include "task_flash.h"

/****************************************************************************
 * Private Data
 ****************************************************************************/

struct alarm_value  alarmdata;

/****************************************************************************
 * mid
 * liushuhe
 * 2017.10.23
 ****************************************************************************/
char * mid(char *dst,char *src, int n,int m) /*nΪ���ȣ�mΪλ��*/  
{  
    char *p = src;  
    char *q = dst;  
    int len = strlen(src);  
    if(n>len) n = len-m;    /*�ӵ�m�������*/  
    if(m<0) m=0;    /*�ӵ�һ����ʼ*/  
    if(m>len) return NULL;  
    p += m;  
    while(n--) *(q++) = *(p++);  
    *(q++)='\0'; /*�б�Ҫ�𣿺��б�Ҫ*/  
    return dst;  
}  

/****************************************************************************
 * analyflashdata
 * liushuhe
 * 2017.10.23
 ****************************************************************************/
void analyflashdata(char **pcTempBuf)
{
    char   TempBuf[100];
	//get alarm data
	if(strstr(pcTempBuf[2],"mb=") != NULL)
	{
		mid(TempBuf,pcTempBuf[2],(strlen(pcTempBuf[2])-3),3);
		if(strstr(TempBuf,"NULL") != NULL)
		{
			alarmdata.vcc_mb = VCC_MB_DEF;
		}
		else
		{
			alarmdata.vcc_mb = atof(TempBuf);
		}
		printf("mb= %s,%.2f\n",TempBuf,alarmdata.vcc_mb);
	}
	if(strstr(pcTempBuf[3],"tempretrue=") != NULL)
	{
		mid(TempBuf,pcTempBuf[3],(strlen(pcTempBuf[3])-11),11);
		if(strstr(TempBuf,"NULL") != NULL)
		{
			alarmdata.tempretrue = TEMPRETURE_DEF;
		}
		else
		{
			alarmdata.tempretrue = atof(TempBuf);
		}
		printf("tempretrue= %s,%.2f\n",TempBuf,alarmdata.tempretrue);
	}
	if(strstr(pcTempBuf[4],"humidity=") != NULL)
	{
		mid(TempBuf,pcTempBuf[4],(strlen(pcTempBuf[4])-9),9);
		if(strstr(TempBuf,"NULL") != NULL)
		{
			alarmdata.humidity = HUMIDITY_DEF;
		}
		else
		{
			alarmdata.humidity = atof(TempBuf);
		}
		printf("humidity= %s,%.2f\n",TempBuf,alarmdata.humidity);
	}
	if(strstr(pcTempBuf[5],"co=") != NULL)
	{
		mid(TempBuf,pcTempBuf[5],(strlen(pcTempBuf[5])-3),3);
		if(strstr(TempBuf,"NULL") != NULL)
		{
			alarmdata.co = CO_DEF;
		}
		else
		{
			alarmdata.co = atof(TempBuf);
		}
		printf("co= %s,%.2f\n",TempBuf,alarmdata.co);
	}
	if(strstr(pcTempBuf[6],"h2s=") != NULL)
	{
		mid(TempBuf,pcTempBuf[6],(strlen(pcTempBuf[6])-4),4);
		if(strstr(TempBuf,"NULL") != NULL)
		{
			alarmdata.h2s = H2S_DEF;
		}
		else
		{
			alarmdata.h2s = atof(TempBuf);
		}
		printf("h2s= %s,%.2f\n",TempBuf,alarmdata.h2s);
	}
	if(strstr(pcTempBuf[7],"nh3=") != NULL)
	{
		mid(TempBuf,pcTempBuf[7],(strlen(pcTempBuf[7])-4),4);
		if(strstr(TempBuf,"NULL") != NULL)
		{
			alarmdata.nh3 = NH3_DEF;
		}
		else
		{
			alarmdata.nh3 = atof(TempBuf);
		}
		printf("nh3= %s,%.2f\n",TempBuf,alarmdata.nh3);
	}
	if(strstr(pcTempBuf[8],"o2=") != NULL)
	{
		mid(TempBuf,pcTempBuf[8],(strlen(pcTempBuf[8])-3),3);
		if(strstr(TempBuf,"NULL") != NULL)
		{
			alarmdata.o2 = O2_DEF;
		}
		else
		{
			alarmdata.o2 = atof(TempBuf);
		}
		printf("o2= %s,%.2f\n",TempBuf,alarmdata.o2);
	}
	if(strstr(pcTempBuf[9],"water=") != NULL)
	{
		mid(TempBuf,pcTempBuf[9],(strlen(pcTempBuf[9])-6),6);
		if(strstr(TempBuf,"NULL") != NULL)
		{
			alarmdata.water = WATER_DEF;
		}
		else
		{
			alarmdata.water = atof(TempBuf);
		}
		printf("water= %s,%.2f\n",TempBuf,alarmdata.water);
	}
}

/****************************************************************************
 * slave_flash
 * liushuhe
 * 2017.10.23
 ****************************************************************************/

int master_flash(int argc, char *argv[])
{
    char   *pcTempBuf[255];
    char   *pChar = ";";
	int		cCharNum = 0;

	FAR uint32_t *buffer;
	ssize_t nbytes;
	int fd;

	buffer = (FAR uint32_t *)malloc(200);
	if (!buffer)
	{
		printf("ERROR: failed to allocate a sector buffer\n");
	}

	//check flash
	fd = open(CONFIG_EXAMPLES_FLASH_DEVPATH, O_RDONLY);
	if (fd < 0)
	{
		printf("slave_flash: open %s failed: %d\n", CONFIG_EXAMPLES_FLASH_DEVPATH, errno);
	}
	nbytes = read(fd, buffer, 200);
	if (nbytes < 0)
	{
		printf("ERROR: read from /dev/mtd0 failed: %d\n", errno);
	}
	else
	{
		if((strstr((char *)buffer,"##time=") != NULL)&&(strlen((char *)buffer) > 50))
		{
			printf("read flash data:%s\n",buffer);
			cCharNum = 0;
			memset(pcTempBuf, 0, sizeof(pcTempBuf));
			pcTempBuf[0] = strtok((char*)buffer, pChar);
			while((pcTempBuf[++cCharNum] = strtok(NULL, pChar))!= NULL)  																																											//�ֽ��ַ���
			{
			}
			//get alarm data
			analyflashdata((char **)&pcTempBuf);
		}
		else
		{
			close(fd);
			//init flash data
			fd = open(CONFIG_EXAMPLES_FLASH_DEVPATH, O_WRONLY);
			if (fd < 0)
			{
				printf("slave_flash: open %s failed: %d\n", CONFIG_EXAMPLES_FLASH_DEVPATH, errno);
			}
			
			sprintf((char*)buffer,"##time=20151020170733;locker=off;mb=%.2f;tempretrue=%.2f;humidity=%.2f;co=%.2f;h2s=%.2f;nh3=%.2f;o2=%.2f;water=%.2f;sb=%.2f;id=123@@\n",
								VCC_MB_DEF,TEMPRETURE_DEF,HUMIDITY_DEF,CO_DEF,H2S_DEF,NH3_DEF,O2_DEF,WATER_DEF,VCC_SB_DEF);
			nbytes = write(fd, buffer, strlen((char *)buffer));
			if (nbytes < 0)
			{
				printf("ERROR: write to /dev/mtd0 failed: %d\n", errno);
			}

		  	close(fd);
			alarmdata.vcc_mb		= VCC_MB_DEF;
			alarmdata.tempretrue 	= TEMPRETURE_DEF;
			alarmdata.humidity 		= HUMIDITY_DEF;
			alarmdata.co 			= CO_DEF;
			alarmdata.h2s 			= H2S_DEF;
			alarmdata.nh3 			= NH3_DEF;
			alarmdata.o2 			= O2_DEF;
			alarmdata.water 		= WATER_DEF;
		}
	}
	close(fd);
	

	while(1)
	{
		sleep(1);
		if(GprsData.set_slavetime_flag == 1)
		{
			GprsData.set_slavetime_flag = 0;
			fd = open(CONFIG_EXAMPLES_FLASH_DEVPATH, O_WRONLY);
			if (fd < 0)
			{
				printf("slave_flash: open %s failed: %d\n", CONFIG_EXAMPLES_FLASH_DEVPATH, errno);
			}
			//send time
			sprintf((char*)buffer,"%s",GprsData.download_data.time);
			nbytes = write(fd, buffer, strlen((char *)buffer));
			if (nbytes < 0)
			{
				printf("ERROR: write to /dev/mtd0 failed: %d\n", errno);
			}
			if(strstr(buffer,"##time=") != NULL)
			{
				printf("refresh alarm data:%s\n",buffer);
				cCharNum = 0;
				memset(pcTempBuf, 0, sizeof(pcTempBuf));
				pcTempBuf[0] = strtok((char*)buffer, pChar);
				while((pcTempBuf[++cCharNum] = strtok(NULL, pChar))!= NULL)  																																											//�ֽ��ַ���
				{
				}
				analyflashdata((char **)&pcTempBuf);
			}
			close(fd);
		}
	}

  return 0;
}



